\
import streamlit as st
import pandas as pd
from db import upsert, delete, fetchall
from utils import compute_markdown_price

st.set_page_config(page_title="Itens", layout="wide")
st.title("Itens")

with st.form("add_item", clear_on_submit=True):
    st.subheader("Adicionar / Atualizar")
    sku = st.text_input("SKU (ex.: BH-2508-0001)")
    consignor_id = st.text_input("ConsignanteID (ou deixe vazio para doação)")
    acquisition_type = st.selectbox("Tipo de aquisição", ["consignação", "doação", "compra"])
    category = st.selectbox("Categoria", ["Vestido","Camisa","Camiseta","Calça","Jeans","Saia","Blazer","Casaco","Short","Macacão","Sapato","Bolsa","Acessório"])
    subcategory = st.text_input("Subcategoria", value="")
    brand = st.text_input("Marca", value="")
    gender = st.selectbox("Gênero", ["F","M","Unissex"])
    size = st.text_input("Tamanho (ex.: M, 40)")
    fit = st.selectbox("Modelagem", ["Ajustada","Regular","Ampla"])
    color = st.text_input("Cor")
    fabric = st.text_input("Tecido")
    condition = st.selectbox("Condição", ["A","A-","B","C"])
    flaws = st.text_area("Defeitos (se houver)", value="")
    bust = st.number_input("Busto (cm)", value=0.0, step=0.5)
    waist = st.number_input("Cintura (cm)", value=0.0, step=0.5)
    length = st.number_input("Comprimento (cm)", value=0.0, step=0.5)
    cost = st.number_input("Custo (R$)", value=0.0, step=1.0)
    list_price = st.number_input("Preço de lista (R$)", value=0.0, step=1.0)
    stage = st.selectbox("Etapa de desconto", [0,1,2,3], index=0)
    acquired_at = st.date_input("Entrada em")
    listed_at = st.date_input("Listado em")
    channel_listed = st.selectbox("Canal listagem", ["Loja","Instagram","WhatsApp","Online"])
    photos_url = st.text_input("URL de fotos (opcional)")
    notes = st.text_area("Observações", value="")
    active = st.checkbox("Ativo", value=True)
    submitted = st.form_submit_button("Salvar")
    if submitted:
        if not sku:
            st.error("SKU é obrigatório.")
        else:
            upsert("items", "sku", dict(
                sku=sku, consignor_id=consignor_id or None, acquisition_type=acquisition_type,
                category=category, subcategory=subcategory, brand=brand, gender=gender, size=size, fit=fit,
                color=color, fabric=fabric, condition=condition, flaws=flaws, bust=bust, waist=waist, length=length,
                cost=cost, list_price=list_price, markdown_stage=int(stage), acquired_at=str(acquired_at), listed_at=str(listed_at),
                channel_listed=channel_listed, sold_at=None, sale_price=None, channel_sold=None, days_on_hand=None,
                photos_url=photos_url, notes=notes, active=int(active)
            ))
            st.success(f"Item {sku} salvo. Preço atual com desconto: R$ {compute_markdown_price(list_price, int(stage)):.2f}")

st.divider()
st.subheader("Estoque")
query = """
SELECT sku, consignor_id, acquisition_type, category, brand, size, condition,
       list_price, markdown_stage, ROUND(list_price * (1-CASE markdown_stage
           WHEN 0 THEN 0.0 WHEN 1 THEN 0.10 WHEN 2 THEN 0.25 WHEN 3 THEN 0.40 ELSE 0 END),2) AS preco_atual,
       channel_listed, listed_at, photos_url, active
FROM items
ORDER BY listed_at DESC, sku DESC;
"""
cols, rows = fetchall(query)
df = pd.DataFrame(rows, columns=cols)
st.dataframe(df, use_container_width=True)

del_sku = st.text_input("Excluir item (SKU)")
if st.button("Excluir item"):
    if del_sku:
        delete("items", "sku", del_sku)
        st.success(f"Item {del_sku} excluído (se existia).")
    else:
        st.error("Informe um SKU.")
