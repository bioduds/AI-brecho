\
import streamlit as st
import pandas as pd
from db import upsert, delete, fetchall

st.set_page_config(page_title="Consignantes", layout="wide")
st.title("Consignantes")

with st.form("add_consignor", clear_on_submit=True):
    st.subheader("Adicionar / Atualizar")
    id_ = st.text_input("ID (ex.: C0001)", value="")
    name = st.text_input("Nome")
    whatsapp = st.text_input("WhatsApp")
    email = st.text_input("Email")
    pix_key = st.text_input("Chave Pix")
    percent = st.number_input("Percentual consignante (0–1)", value=0.5, step=0.05)
    notes = st.text_area("Observações")
    active = st.checkbox("Ativo", value=True)
    submitted = st.form_submit_button("Salvar")
    if submitted:
        if not id_ or not name:
            st.error("ID e Nome são obrigatórios.")
        else:
            upsert("consignors", "id", dict(
                id=id_, name=name, whatsapp=whatsapp, email=email, pix_key=pix_key,
                percent=percent, notes=notes, active=int(active)
            ))
            st.success(f"Consignante {id_} salvo.")

st.divider()
st.subheader("Lista")
cols, rows = fetchall("SELECT id,name,whatsapp,email,pix_key,percent,active FROM consignors ORDER BY id;")
df = pd.DataFrame(rows, columns=cols)
st.dataframe(df, use_container_width=True)

delete_id = st.text_input("Excluir consignante (ID)")
if st.button("Excluir"):
    if delete_id:
        delete("consignors", "id", delete_id)
        st.success(f"Consignante {delete_id} excluído (se existia).")
    else:
        st.error("Informe um ID.")
