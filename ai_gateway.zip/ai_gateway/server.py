from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from typing import List, Optional
from PIL import Image
import io, uuid, numpy as np, cv2

from embedder import ImageEmbedder
from vstore import upsert_item_embedding, query_by_vector
from llm import intake_normalize, price_suggest

app = FastAPI(title="AI Gateway — Brechó", version="0.1.0")
EMB = ImageEmbedder()

def read_images(files: List[UploadFile]):
    imgs = []
    for f in files:
        b = f.file.read()
        imgs.append(Image.open(io.BytesIO(b)).convert("RGB"))
        f.file.seek(0)
    return imgs

def detect_qr_in_images(files: List[UploadFile]):
    detector = cv2.QRCodeDetector()
    for f in files:
        arr = np.frombuffer(f.file.read(), dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        f.file.seek(0)
        if img is None:
            continue
        val, pts, _ = detector.detectAndDecode(img)
        if val:
            return val.strip()
    return None

@app.post("/search_by_image")
async def search_by_image(image: UploadFile = File(...), top_k: int = Form(5)):
    pil = read_images([image])[0]
    vec = EMB.embed_images([pil])[0]
    results = query_by_vector(vec, top_k=top_k)
    return JSONResponse({"results": results})

@app.post("/index/upsert")
async def index_upsert(
    images: List[UploadFile] = File(...),
    sku: Optional[str] = Form(None),
    consignor_id: Optional[str] = Form(None),
    category: Optional[str] = Form(None),
    brand: Optional[str] = Form(None),
    size: Optional[str] = Form(None),
    condition: Optional[str] = Form(None),
    list_price: Optional[float] = Form(None),
    extras_json: Optional[str] = Form(None)
):
    pil = read_images(images)
    vecs = EMB.embed_images(pil)
    pooled = EMB.pool_views(vecs)
    item_id = sku or str(uuid.uuid4())
    metadata = {
        "sku": item_id,
        "consignor_id": consignor_id,
        "category": category, "brand": brand, "size": size, "condition": condition,
        "list_price": list_price,
        "extras": extras_json
    }
    upsert_item_embedding(item_id, pooled, metadata)
    return JSONResponse({"ok": True, "sku": item_id, "metadata": metadata})

@app.post("/intake/autoregister")
async def intake_autoregister(images: List[UploadFile] = File(...)):
    if len(images) < 2:
        return JSONResponse({"error": "Envie pelo menos 2 fotos"}, status_code=400)

    consignor_id = detect_qr_in_images(images)
    pil = read_images(images)
    vecs = EMB.embed_images(pil)
    pooled = EMB.pool_views(vecs)
    similar = query_by_vector(pooled, top_k=5)

    hints = [{"filename": f.filename} for f in images]
    normalized = intake_normalize({"hints": hints, "consignor_id": consignor_id})
    price_info = price_suggest({
        "categoria": normalized.get("Categoria"),
        "marca": normalized.get("Marca"),
        "condicao": normalized.get("Condição"),
        "estagio": 0
    })
    sku = str(uuid.uuid4())[:8].upper()

    return JSONResponse({
        "consignor_id": consignor_id,
        "proposal": {"sku": sku, "cadastro": normalized, "price": price_info},
        "similar_topk": similar
    })
