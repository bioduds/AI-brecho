OLLAMA_URL = "http://localhost:11434/api/generate"
GEMMA_MODEL = "gemma2:2b"  # adjust when you have gemma3:4b locally
CHROMA_PATH = "./vectordb"
EMBED_MODEL = "ViT-B-32"  # OpenCLIP backbone
DEVICE = "cpu"            # 'cuda' if available
