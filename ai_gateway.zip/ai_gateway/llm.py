import requests, json, re
from config import OLLAMA_URL, GEMMA_MODEL

SYS_INTAKE = (
"You are an expert cataloguer for a Brazilian thrift shop (brechó). "
"Normalize fields and return STRICT JSON with keys: "
'{"Categoria","Subcategoria","Marca","Gênero","Tamanho","Modelagem","Cor","Tecido","Condição","Defeitos","TituloIG","Tags"}.'
"Condição must be one of: A, A-, B, C. Keep text concise in PT-BR."
)

SYS_PRICE = (
"Você é um assistente de precificação de brechó em BH. "
"Com base em categoria, marca (nível), condição e estágio de desconto, sugira uma FAIXA em reais e um MOTIVO curto. "
"Respeite: sem descontos abaixo da margem mínima. "
"Retorne JSON: {'Faixa':'R$min–R$max','Motivo':'...'}"
)

def ollama_generate(prompt: str, system: str = "") -> str:
    data = {
        "model": GEMMA_MODEL,
        "prompt": (system + "\n\n" + prompt).strip(),
        "stream": False,
        "options": {"temperature": 0.2}
    }
    r = requests.post(OLLAMA_URL, json=data, timeout=60)
    r.raise_for_status()
    return r.json().get("response","").strip()

def _parse_json(txt: str) -> dict:
    m = re.search(r'\{.*\}', txt, re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(0))
    except Exception:
        return {}

def intake_normalize(context: dict) -> dict:
    prompt = "Dados para padronizar (PT-BR) em JSON válido:\n" + json.dumps(context, ensure_ascii=False)
    return _parse_json(ollama_generate(prompt, system=SYS_INTAKE))

def price_suggest(context: dict) -> dict:
    prompt = "Contexto de preço (PT-BR):\n" + json.dumps(context, ensure_ascii=False)
    return _parse_json(ollama_generate(prompt, system=SYS_PRICE))
